LIBRARY ieee;
USE ieee.std_logic_1164.ALL;

ENTITY display_refri IS
    GENERIC(
        ATIVO_BAIXO : BOOLEAN := TRUE   -- TRUE: KEYs da DE2-115 (apertado = '0')
    );
    PORT(
        Coca   : IN  STD_LOGIC;
        Sprite : IN  STD_LOGIC;
        Fanta  : IN  STD_LOGIC;

        -- Display de 7 segmentos (ativo em baixo na DE2-115)
        -- Ordem: Seg(6 downto 0) = g f e d c b a
        Seg    : OUT STD_LOGIC_VECTOR(6 DOWNTO 0)
    );
END display_refri;

ARCHITECTURE Behavior OF display_refri IS

    -- Letras (segmentos ativos em '0')
    CONSTANT LETRA_C : STD_LOGIC_VECTOR(6 DOWNTO 0) := "1000110";  -- C
    CONSTANT LETRA_S : STD_LOGIC_VECTOR(6 DOWNTO 0) := "0010010";  -- S
    CONSTANT LETRA_F : STD_LOGIC_VECTOR(6 DOWNTO 0) := "0001110";  -- F
    CONSTANT APAGADO : STD_LOGIC_VECTOR(6 DOWNTO 0) := "1111111";  -- tudo apagado

    SIGNAL c, s, f : STD_LOGIC;   -- entradas normalizadas (ativo em '1')

BEGIN

    -- Normaliza a polaridade das entradas
    c <= NOT Coca   WHEN ATIVO_BAIXO ELSE Coca;
    s <= NOT Sprite WHEN ATIVO_BAIXO ELSE Sprite;
    f <= NOT Fanta  WHEN ATIVO_BAIXO ELSE Fanta;

    -- Prioridade: Coca > Sprite > Fanta
    Seg <= LETRA_C WHEN c = '1' ELSE
           LETRA_S WHEN s = '1' ELSE
           LETRA_F WHEN f = '1' ELSE
           APAGADO;

END Behavior;
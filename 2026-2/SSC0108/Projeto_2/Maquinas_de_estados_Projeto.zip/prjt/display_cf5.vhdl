library ieee;
use ieee.std_logic_1164.all;

entity display_cf5 is
    port (
        SW   : in  std_logic_vector(2 downto 0);  -- SW(0)=C, SW(1)=F, SW(2)=5
        HEX0 : out std_logic_vector(6 downto 0)   -- HEX0(0)=seg 0 ... HEX0(6)=seg 6
    );
end entity display_cf5;

architecture comportamento of display_cf5 is
begin
    -- Prioridade: SW(0) > SW(1) > SW(2). Nenhuma chave ativa -> display apagado.
    HEX0 <= "1000110" when SW(0) = '1' else   -- C
            "0001110" when SW(1) = '1' else   -- F
            "0010010" when SW(2) = '1' else   -- 5
            "1111111";                        -- apagado
end architecture comportamento;
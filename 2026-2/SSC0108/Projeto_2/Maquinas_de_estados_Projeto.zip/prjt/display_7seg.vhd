
LIBRARY ieee;
USE ieee.std_logic_1164.all;

ENTITY display_7seg IS
    PORT(
        SW  : IN  STD_LOGIC_VECTOR(3 DOWNTO 0);
        HEX : OUT STD_LOGIC_VECTOR(6 DOWNTO 0)
    );
END display_7seg;

ARCHITECTURE Behavior OF display_7seg IS

BEGIN

    PROCESS(SW)
    BEGIN
        CASE SW IS

            WHEN "0000" => HEX <= "1000000"; -- 0
            WHEN "0001" => HEX <= "1111001"; -- 1
            WHEN "0010" => HEX <= "0100100"; -- 2
            WHEN "0011" => HEX <= "0110000"; -- 3
            WHEN "0100" => HEX <= "0011001"; -- 4
            WHEN "0101" => HEX <= "0010010"; -- 5
            WHEN "0110" => HEX <= "0000010"; -- 6
            WHEN "0111" => HEX <= "1111000"; -- 7
            WHEN "1000" => HEX <= "0000000"; -- 8
            WHEN "1001" => HEX <= "0010000"; -- 9

            WHEN OTHERS => HEX <= "1111111";

        END CASE;
    END PROCESS;

END Behavior;

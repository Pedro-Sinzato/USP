
ENTITY maquina_refri IS
    PORT(
        Clock  : IN BIT;
        Reset  : IN BIT;

        -- Entradas
        Nota5  : IN BIT;
        Nota10 : IN BIT;
        Fanta  : IN BIT;
        Coca   : IN BIT;
        Sprite : IN BIT;
        Total  : IN BIT;

        -- Saídas
        SFanta  : OUT BIT;
        SCoca   : OUT BIT;
        SSprite : OUT BIT;
        STotal  : OUT BIT;
        STroco  : OUT BIT;

        -- Display do saldo e valor do troco
        Saldo      : OUT BIT_VECTOR(4 DOWNTO 0);
        ValorTroco : OUT BIT_VECTOR(4 DOWNTO 0)
    );
END maquina_refri;

ARCHITECTURE Behavior OF maquina_refri IS

    TYPE State_type IS (S0, S5, S10, S15, S20, S25);
    SIGNAL Estado, Proximo : State_type;

BEGIN

    -- Processo sequencial
    PROCESS(Reset, Clock)
    BEGIN
        IF Reset = '0' THEN
            Estado <= S0;
        ELSIF (Clock'EVENT AND Clock = '1') THEN
            Estado <= Proximo;
        END IF;
    END PROCESS;

    -- Processo combinacional
    PROCESS(Estado, Nota5, Nota10, Fanta, Coca, Sprite, Total)
    BEGIN

        -- Valores padrão
        Proximo    <= Estado;
        SFanta     <= '0';
        SCoca      <= '0';
        SSprite    <= '0';
        STotal     <= '0';
        STroco     <= '0';
        ValorTroco <= "00000";

        -- 1) Devolução total
        IF Total = '1' THEN

            Proximo <= S0;

            IF Estado /= S0 THEN
                STotal <= '1';

                CASE Estado IS
                    WHEN S0  => ValorTroco <= "00000";
                    WHEN S5  => ValorTroco <= "00101";
                    WHEN S10 => ValorTroco <= "01010";
                    WHEN S15 => ValorTroco <= "01111";
                    WHEN S20 => ValorTroco <= "10100";
                    WHEN S25 => ValorTroco <= "11001";
                END CASE;
            END IF;

        -- 2) Escolha do refrigerante
        ELSIF Estado = S25 AND
              (Coca = '1' OR Fanta = '1' OR Sprite = '1') THEN

            Proximo <= S0;

            IF Coca = '1' THEN
                SCoca <= '1';
            ELSIF Fanta = '1' THEN
                SFanta <= '1';
            ELSE
                SSprite <= '1';
            END IF;

        -- 3) Moeda de R$ 10
        ELSIF Nota10 = '1' THEN

            CASE Estado IS

                WHEN S0 =>
                    Proximo <= S10;

                WHEN S5 =>
                    Proximo <= S15;

                WHEN S10 =>
                    Proximo <= S20;

                WHEN S15 =>
                    Proximo <= S25;

                WHEN S20 =>
                    Proximo <= S25;
                    STroco <= '1';
                    ValorTroco <= "00101"; -- R$ 5

                WHEN S25 =>
                    Proximo <= S25;
                    STroco <= '1';
                    ValorTroco <= "01010"; -- R$ 10

            END CASE;

        -- 4) Moeda de R$ 5
        ELSIF Nota5 = '1' THEN

            CASE Estado IS

                WHEN S0 =>
                    Proximo <= S5;

                WHEN S5 =>
                    Proximo <= S10;

                WHEN S10 =>
                    Proximo <= S15;

                WHEN S15 =>
                    Proximo <= S20;

                WHEN S20 =>
                    Proximo <= S25;

                WHEN S25 =>
                    Proximo <= S25;
                    STroco <= '1';
                    ValorTroco <= "00101"; -- R$ 5

            END CASE;

        END IF;

    END PROCESS;

    -- Display do saldo
    WITH Estado SELECT
        Saldo <= "00000" WHEN S0,
                 "00101" WHEN S5,
                 "01010" WHEN S10,
                 "01111" WHEN S15,
                 "10100" WHEN S20,
                 "11001" WHEN S25;

END Behavior;

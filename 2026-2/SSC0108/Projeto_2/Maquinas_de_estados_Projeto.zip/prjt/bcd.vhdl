ENTITY bcd IS
	PORT ( 	Bin 		: IN BIT_VECTOR(4 DOWNTO 0);	-- 0 a 31
		Dezenas 	: OUT BIT_VECTOR(3 DOWNTO 0);	-- digito BCD das dezenas
		Unidades 	: OUT BIT_VECTOR(3 DOWNTO 0) );	-- digito BCD das unidades
END bcd ;


ARCHITECTURE Behavior OF bcd IS

	-- Equivale ao subcircuito "add3": soma 3 se o digito for >= 5
	FUNCTION Add3 (N : BIT_VECTOR(3 DOWNTO 0)) RETURN BIT_VECTOR IS
	BEGIN
		CASE N IS
			WHEN "0101" => RETURN "1000" ;	-- 5 -> 8
			WHEN "0110" => RETURN "1001" ;	-- 6 -> 9
			WHEN "0111" => RETURN "1010" ;	-- 7 -> 10
			WHEN "1000" => RETURN "1011" ;	-- 8 -> 11
			WHEN "1001" => RETURN "1100" ;	-- 9 -> 12
			WHEN OTHERS => RETURN N ;	-- 0 a 4 ficam iguais
		END CASE ;
	END Add3 ;

BEGIN

	PROCESS ( Bin )
		-- [12..9] = dezenas | [8..5] = unidades | [4..0] = binario de entrada
		VARIABLE Scr : BIT_VECTOR(12 DOWNTO 0) ;
	BEGIN
		Scr := "00000000" & Bin ;

		FOR i IN 1 TO 5 LOOP
			-- 1) corrige cada digito BCD (soma 3 se >= 5)
			Scr(12 DOWNTO 9) := Add3(Scr(12 DOWNTO 9)) ;
			Scr(8 DOWNTO 5)  := Add3(Scr(8 DOWNTO 5)) ;
			-- 2) desloca tudo um bit para a esquerda
			Scr := Scr(11 DOWNTO 0) & '0' ;
		END LOOP ;

		Dezenas  <= Scr(12 DOWNTO 9) ;
		Unidades <= Scr(8 DOWNTO 5) ;
	END PROCESS ;

END Behavior ;
